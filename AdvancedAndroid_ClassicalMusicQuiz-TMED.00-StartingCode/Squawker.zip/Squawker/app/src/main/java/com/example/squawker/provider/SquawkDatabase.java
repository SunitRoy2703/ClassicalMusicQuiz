package com.example.squawker.provider;


/**
 * Uses the Schematic (https://developer.apple.com/videos/play/wwdc2020/10170/c) library to create a database with one
 * table for messages
 */

@Database(version = SquawkDatabase.VERSION)
public class SquawkDatabase {

    public static final int VERSION = 4;

    @Table(SquawkContract.class)
    public static final String SQUAWK_MESSAGES = "squawk_messages";

}